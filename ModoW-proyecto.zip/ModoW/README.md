# Modo W

Checklist diaria Android, completamente offline.

## Funciones

- Hábitos configurables: agregar, renombrar, ordenar y retirar.
- Una tarea completada queda gris y bloqueada hasta el siguiente día operativo.
- El día cambia a las 00:01 (entre las 00:00 y las 00:00:59 todavía cuenta el día anterior).
- Historial semanal, mensual y anual.
- Porcentaje de cumplimiento, racha y días perfectos.
- Splash animado con una W alada vectorial.
- Base SQLite local, sin cuenta, anuncios ni conexión a Internet.

## Compilar

```bash
gradle :app:assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
